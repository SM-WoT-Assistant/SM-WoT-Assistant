------------------------------------------------------------------------
 The simple disassembly package for Python 2.6-3.6
------------------------------------------------------------------------

Last update: 23/07/2017

2014-2017 (C) StranikS_Scan for http://www.koreanrandom.com/forum/