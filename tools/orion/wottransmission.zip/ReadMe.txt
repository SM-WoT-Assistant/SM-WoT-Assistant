------------------------------------------------------------------------
 The transmitter for WorldOfTanks with Python 2.7.X only
------------------------------------------------------------------------

Last update: 23/08/2017

2014-2017 (C) StranikS_Scan for http://www.koreanrandom.com/forum/